import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

public abstract class Structure {

    private String title;
    protected int screen_width, screen_height;

    public Structure(String title, int screen_width, int screen_height) {
        this.title = title;
        this.screen_width = screen_width;
        this.screen_height = screen_height;
    }

    public abstract void update();
    public void draw(Graphics pen) {
        pen.setFont(new Font("Arial",1,20));
        pen.setColor(Color.BLACK);
        pen.drawString(title, (screen_width / 2) - (pen.getFontMetrics().stringWidth(title) / 2), 50);
    }
    
}
