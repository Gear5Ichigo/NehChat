import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.BasicStroke;

public class LinkedList<T> extends Structure {
    
    private Node<T> head; 

    public LinkedList(String title, int screen_width, int screen_height) {
        super(title, screen_width, screen_height);
        head = null;
    }
    public void update() {}

    public void draw(Graphics pen) {
        super.draw(pen);
        
        // Empty List
        if(head == null) {
            String output = "The Linked List is currently empty (head ---> null)";
            pen.setColor(Color.RED);
            int valueX = (screen_width / 2) - (pen.getFontMetrics().stringWidth(output) / 2);
            pen.drawString(output, valueX , screen_height / 2);
        } else {
            //head.draw(pen);
        }
    }

    public class Node<T> {
        private T value;
        private Node<T> next;
        private int x, y;

        public Node(T value, Node<T> next) {
            this.value = value;
            this.next = next;
            // default location for Node to "spawn"
            this.x = screen_width - 200;
            this.y = 200;
        }
    }

}
