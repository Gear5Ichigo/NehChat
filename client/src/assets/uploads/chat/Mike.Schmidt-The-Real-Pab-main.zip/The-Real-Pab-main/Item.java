import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;


public class Item extends GameObject{

    public static  ArrayList<Item> every= new ArrayList<Item>();
    BufferedImage foto;


      public Item(int x, int y, int w, int h, Color c, String g) {
        super(x, y, w, h, c);
        
        try{
            this.foto = ImageIO.read(new File(g));

        }catch (IOException e){}
        every.add(this);
    }

        
    public void draw(Graphics pen) { 
        super.draw(pen);
        pen.drawImage(foto, x, y, null);
    
    }

    public void update() {
        //do cool thing!!!    

 
    }


}
