import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;


public class Npc extends GameObject{

    private int xVelocity, yVelocity;
    protected int lives;
    protected NpcType type;
    BufferedImage foto;

    public Npc(int x, int y, int w, int h, Color c, String g, int lives, NpcType type) {
        super(x, y, w, h, c);
        xVelocity = 50;
        yVelocity = 50;
        this.type = type;
        this.lives=lives;


        try{
            this.foto = ImageIO.read(new File(g));
        
        }catch (IOException e){}
    }

    public void die(){

    }

    public void update() {
 
       // if(type.equals(NpcType.PASSIVE)) {
        //    System.out.println("Pab");
       // }

       if(lives==0){
        die();
       }

                

            }
        
    
    public void draw(Graphics pen) { 
        super.draw(pen);
        pen.drawImage(foto, x, y, null);
        }
    
    }








