import java.awt.Graphics;
import java.awt.event.KeyEvent;
import org.w3c.dom.events.MouseEvent;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;



public abstract class GameObject{
    protected int x;
    protected int y; 
    protected int w, h;
    protected Color c;
    BufferedImage pictura;

    public GameObject(int x, int y, int w, int h, Color c){
        this.x=x;
        this.y=y;
        this.w=w;
        this.h=h;
        this.c=c;
        
    }

    public GameObject(int x, int y, int w, int h, Color c, String g){
        this.x=x;
        this.y=y;
        this.w=w;
        this.h=h;
        this.c=c;
        try{
            this.pictura = ImageIO.read(new File(g));
        
        }catch (IOException e){}
    }
    public abstract void update();

    public void draw(Graphics pen) {
       //pen.setColor(c);
       //pen.fillRect(x, y, w, h);
       pen.drawImage(pictura, x, y, null);
    }

    public boolean collidingWith(GameObject otherOb) {
        if(x<=otherOb.x+otherOb.w && x+w>=otherOb.x && y+h>=otherOb.y && y <= otherOb.y+otherOb.h) 
            return true;
        return false;
    }

    public boolean collidingWith(int OOx, int OOy, int OOw, int OOh) {
        if(x<=OOx+OOw && x+w>=OOx&& y+h>=OOy && y <= OOy+OOh) 
            return true;
        return false;
    }


    public void keyPressed(KeyEvent ke) {}


// wow
}
