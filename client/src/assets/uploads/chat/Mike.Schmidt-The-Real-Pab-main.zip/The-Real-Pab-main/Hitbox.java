import java.awt.Color;
import java.awt.Graphics;

public class Hitbox extends GameObject {
    public boolean coli;

    public Hitbox(int x, int y, int w, int h) {
        super(x, y, w, h, Color.red);
        coli=false;
        
    }

    public void update() {
        
    }

    public void draw(Graphics pen) {
        pen.setColor(c);
        pen.drawRect(x, y, w, h);
    }
    public void update(int x, int y) {
        this.x=x;
        this.y=y;
    }
}
