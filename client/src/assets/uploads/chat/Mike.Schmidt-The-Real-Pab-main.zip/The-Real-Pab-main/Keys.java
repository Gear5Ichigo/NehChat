import java.awt.event.KeyEvent;

public class Keys {
    public static boolean left, right, up, down, space, w, a, s, d, shift = false;
    
    public static void keyPressed(KeyEvent ke) {
        if(ke.getKeyCode() == 37) 
            left=true;
        if(ke.getKeyCode() == 38) 
            up=true;
        if(ke.getKeyCode() == 39) 
            right=true;
        if(ke.getKeyCode() == 40) 
            down=true;

        if(ke.getKeyCode() == 87)
            w=true;
        if(ke.getKeyCode() == 65)
            a=true;
        if(ke.getKeyCode() == 83)
            s=true;
        if(ke.getKeyCode() == 68)
            d=true;
        
        if(ke.getKeyCode() == 32) 
            space=true;
        if(ke.getKeyCode() == 16) 
            shift=true;
    }

    public static void keyReleased(KeyEvent ke) {
        if(ke.getKeyCode() == 37) 
            left=false;
        if(ke.getKeyCode() == 38) 
            up=false;
        if(ke.getKeyCode() == 39) 
            right=false;
        if(ke.getKeyCode() == 40) 
            down=false;

        if(ke.getKeyCode() == 87)
            w=false;
        if(ke.getKeyCode() == 65)
            a=false;
        if(ke.getKeyCode() == 83)
            s=false;
        if(ke.getKeyCode() == 68)
            d=false;
        
        if(ke.getKeyCode() == 32) 
            space=false;
        if(ke.getKeyCode() == 16) 
            shift=false;
    }
}
