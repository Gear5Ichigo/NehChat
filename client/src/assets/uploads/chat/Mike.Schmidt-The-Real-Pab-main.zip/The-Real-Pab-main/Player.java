import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.ArrayList;

public class Player extends GameObject{

    private int xVelocity, yVelocity;
    protected int lives;
    protected int mewStreak;
    private Hitbox[] hitboxes;
    public Keys keys;

    //radious around player
    protected int radX;
    protected int radY;

    protected String skill;

    protected boolean gt;

    BufferedImage guy;

    static int curX, curY;


    public Player(int x, int y, int w, int h, Color c, String g, int lives) {
        super(x, y, w, h, c);
        xVelocity = 6;
        yVelocity = 6;
        this.lives=lives;
        this.mewStreak = 0;
        this.radX= x*100;
        this.radY= y*100;
        this.skill = "silly goose";
        this. curX= x;
        this. curY= y;


        
        try{
            this.guy = ImageIO.read(new File(g));
        
        }catch (IOException e){}


        //hit boxes
        hitboxes=new Hitbox[1];
        hitboxes[0]=new Hitbox(x,y,w,h);


        this.gt=false;

    }
//got dang
    public void update() {
        //do cool thing!!! 
        if(Keys.left || Keys.a) 
        x-=xVelocity;
        curX= x;
        if(Keys.right || Keys.d) 
        x+=xVelocity;  
        curX= x;
        if(Keys.down || Keys.s) 
        y+=yVelocity;  
        this. curY= y;
        if(Keys.up || Keys.w) 
        y-=yVelocity;  
        this. curY= y;

        if(lives > 0){
            mewStreak++;
        }
       // System.out.println(mewStreak);
                

            }
        
            public boolean checkCol(){
                ArrayList<Item> items = Item.every;
                for(int i=0;i<items.size();i++){
                    if(collidingWith(items.get(i)) && y+h==items.get(i).y) {
                        return true;
                    }           
                }
                return false;
            }
  

        
//   o(" >)3 el pescado   o(" >)3 el pescado   o(" >)3 el pescado   o(" >)3 el pescado   o(" >)3 el pescado 
//pain
    
    public void draw(Graphics pen) { 
        super.draw(pen);
        if(gt==false){
        pen.drawImage(guy, x, y, null);
        for(int i=0;i<lives*(lives*10+10);i+=50){
        pen.drawImage(guy, i, 0, null);
        }
        }
    
    }
    public void keyPressed(KeyEvent ke) {
        // 37 (L), 38 (U), 39 (R), 40 (D)
        if(Keys.left || Keys.a) {
            x-= xVelocity;
        } else if(ke.getKeyCode() == 39 || ke.getKeyCode() == 68) {
            x+=xVelocity;
        } else if(Keys.up || Keys.right || Keys.w || Keys.space){
            //nothing
        } else if(ke.getKeyCode()==40 || ke.getKeyCode() == 39 || ke.getKeyCode() == 83 || ke.getKeyCode() == 32){
            y+=yVelocity;
        }
    
    
    }


    public static int getX() {
       return curX;
    }
    public static int getY() {
        return curY;
     }



}
//i'm going to punch a wall :D




