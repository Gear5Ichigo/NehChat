public enum Slot{
    FULL, STACK, EMPTY

}