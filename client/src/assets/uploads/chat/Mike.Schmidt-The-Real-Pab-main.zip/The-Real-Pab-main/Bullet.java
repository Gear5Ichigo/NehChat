import java.awt.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Bullet {
    private int x, y;
    private final int velocity = 10; 
        BufferedImage bull;

    public Bullet(int x, int y) {
        this.x = x;
        this.y = y;

        try{
            this.bull = ImageIO.read(new File("images/bullet.png"));
        
        }catch (IOException e){}
    }

    public void update() {
        x += velocity;
    }

    public void draw(Graphics pen) {
        //pen.setColor(Color.RED);
        //pen.fillRect(x, y+25, 10, 10);
        pen.drawImage(bull, x, y+25, null);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 10, 10);
    }
}
