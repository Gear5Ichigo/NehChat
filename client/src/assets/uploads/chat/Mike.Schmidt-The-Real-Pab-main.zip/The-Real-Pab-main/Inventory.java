import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;


public class Inventory extends GameObject{

    protected int slots;
      
        public Inventory(int x, int y, int w, int h, Color c, String g) {
            super(x, y, w, h, c);
            slots = 9;


        }
        public void update() {
 
                    
    
           }  
        
        public void draw(Graphics pen) { 
            //pen.drawImage(guy, x, y, null);
            pen.setColor(Color.DARK_GRAY);
            for(int i = 0; i < 9; i++) {
                pen.fillRect(100 + (i * 50), 900, 50, 50);
            }
        }
        public void keyPressed(KeyEvent ke) {
            // 37 (L), 38 (U), 39 (R), 40 (D)

        
        }
    
    }
    