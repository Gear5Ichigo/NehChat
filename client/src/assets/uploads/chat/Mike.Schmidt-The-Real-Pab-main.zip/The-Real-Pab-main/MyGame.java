import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;


public class MyGame extends Game  {
    public static final String TITLE = "Day in the life of TJ CARRON";
    public static final int SCREEN_WIDTH = 1700;
    public static final int SCREEN_HEIGHT = 900;
    public static ArrayList<GameObject> allGameObjects= new ArrayList<>();
    public static ArrayList<Item> items= new ArrayList<>();
    public static ArrayList<Screen> allScreens= new ArrayList<>();
    public static Screen activeScreen;
    BufferedImage bg_image;

    private ArrayList<Bullet> bullets;

    public MyGame() {
       
        //player
        allGameObjects.add(new Player(100,200, 50, 50, Color.RED, "images/player/Kalti-gif.gif", 3 ));
        
        bullets = new ArrayList<>();

        //items
        items.add(new Item(300,200, 50, 50, Color.RED, "images/apple_fritter.png" ));
        allGameObjects.add(items.get(0));
        items.add(new Item(900,300, 50, 50, Color.RED, "images/quesitos.png" ));
        allGameObjects.add(items.get(1));
        


        //NPCs
        allGameObjects.add(new Npc(800,200, 50, 50, Color.
        RED, "images/pochita.png", 3 , NpcType.PASSIVE));


        //Screens 
        allScreens.add(new Starter("START", "images/mivida.png", true));
        allScreens.add(new Starter("DEATH", "images/deathScreen.png", false));
        allScreens.add(new Starter("QUIT", "images/quitScreen.png", false));
        allScreens.add(new Starter("PAUSE", "images/mivida.png", false));
       
       //bg image
        try{
            this.bg_image = ImageIO.read(new File("images/bg_image.png"));
        }catch (IOException e){}
        
        
    }
    
    public void update() {
        
        for(int i=0; i<allGameObjects.size();i++){
            if(allGameObjects.get(i).getClass()==allGameObjects.get(0).getClass()){
                allGameObjects.get(i).update();
            }
      
        }
        for(int i=0; i<allScreens.size();i++){
            allScreens.get(i).update();

        }

        for (Bullet bullet : bullets) {
            bullet.update();
        }

 
    }
    
    public void draw(Graphics pen) {
        pen.drawImage(bg_image, 0, 0, null);
        
        for(int i=0; i<allGameObjects.size();i++){
            allGameObjects.get(i).draw(pen);
        }
        for(int i=0; i<allScreens.size();i++){
            allScreens.get(i).draw(pen);
        }

        for (Bullet bullet : bullets) {
            bullet.draw(pen);
        }
    }
        
    @Override
    public void keyTyped(KeyEvent ke) {}

    @Override
    public void keyPressed(KeyEvent ke) {
        Keys.keyPressed(ke);
        for(int i=0; i<allGameObjects.size();i++){
            if(allGameObjects.get(i).getClass()==allGameObjects.get(0).getClass()){
                allGameObjects.get(i).keyPressed(ke);
            }else if (ke.getKeyCode() == KeyEvent.VK_SPACE) {
                bullets.add(new Bullet(Player.getX(), Player.getY()));
            }
      
        }
        //if(){allScreens.get(1).keyPressed(ke);}
        for(int i=0; i<allScreens.size();i++){
            allScreens.get(i).keyPressed(ke);
        }
        
    }

    @Override
    public void keyReleased(KeyEvent ke) {
        Keys.keyReleased(ke);

    }

    @Override
    public void mouseClicked(MouseEvent ke) {}

    @Override
    public void mousePressed(MouseEvent me) {}
    
    @Override
    public void mouseReleased(MouseEvent me) {}

    @Override
    public void mouseEntered(MouseEvent me) {}

    @Override
    public void mouseExited(MouseEvent me) {}
        
        
    //Launches the Game
    public static void main(String[] args) { new MyGame().start(TITLE, SCREEN_WIDTH,SCREEN_HEIGHT); }
}