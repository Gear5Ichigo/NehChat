import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
//import java.util.ArrayList;

public abstract class Screen{
    protected String title;
    BufferedImage screenImage;
    //public static ArrayList<GameObject> everyGameObjects= new ArrayList<>();


    public Screen(String title, String g){
        this.title=title;
        try{
            this.screenImage = ImageIO.read(new File(g));
        
        }catch (IOException e){}
    }
    public abstract void update();
    public void draw(Graphics pen){
        pen.drawImage(screenImage, 0, 0, null);
        //pen.setFont(new Font("Comic Sans Ms",1,80));
        //pen.drawString("q and p", 0, 300);
    }
    public void keyPressed(KeyEvent ke) {
 }

    }
    //public void hide(){}
    //public void show(){}
