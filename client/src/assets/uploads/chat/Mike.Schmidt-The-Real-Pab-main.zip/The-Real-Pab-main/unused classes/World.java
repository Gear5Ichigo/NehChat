import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;


public class World extends GameObject{

    public World() {

        //type, map, objets in the world, wether they interacting or no, solid, see through, etc...
        //
    }



    public void update() {
     

            }
        
    
    public void draw(Graphics pen) { 

        }
    
    }



