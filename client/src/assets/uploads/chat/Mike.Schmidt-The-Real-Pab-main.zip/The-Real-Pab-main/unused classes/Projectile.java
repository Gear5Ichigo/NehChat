import java.awt.*;


public class Projectile{
    private int x, y;
    private static final int velocity = 10;

    public Projectile(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void update() {
        y -= velocity;
    }

    public void draw(Graphics g) {
        g.setColor(Color.YELLOW);
        g.fillRect(x, y, 5, 10);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 5, 10);
    }
}
