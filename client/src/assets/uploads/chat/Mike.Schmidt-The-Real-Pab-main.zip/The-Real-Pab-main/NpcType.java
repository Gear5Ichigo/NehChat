public enum NpcType {
    PASSIVE, NUTRAL, HOSTILE
}
