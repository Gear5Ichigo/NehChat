import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;



public class Starter extends Screen{

    protected boolean active;
    BufferedImage screenImage;

    public Starter(String title, String g, boolean active){
        super(title, g);
        this.active=active;
                try{
            this.screenImage = ImageIO.read(new File(g));
        
        }catch (IOException e){}
    }
    public void update(){}

    public void draw(Graphics pen){
        if(active==true){
        super.draw(pen);
        }
    }

    public void keyPressed(KeyEvent ke) {
        //if(title.equals("QUIT")==false){
        if(active==true){
            active=false;
        }else if(active==false &&  ke.getKeyCode() == 80 && title.equals("PAUSE") ){
            active=true;
        }else if(active==false  &&  ke.getKeyCode() == 81 && title.equals("QUIT")){
            active=true;
            System.exit(0);
        }
   // }
    }
    public boolean getActive(){
        return active;
    }
    //public void hide(){}
    //public void show(){}
}

